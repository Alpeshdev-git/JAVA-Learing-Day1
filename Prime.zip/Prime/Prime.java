import java.util.Scanner;
public class Prime{
    public static void main(String [] args)
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the value :");
         int n;
         n=sc.nextInt();
         boolean flag=true;
         if(n<2)
         {
            System.out.println(n+"the number is not prime ");
         }
         for(int i=2;i<n/2;i++)
         {
            if(n%i==0)
            {
                flag=false;
                break;
            }
         }

         if(flag)
         {
            System.out.println(n+ " is  a prime number ");
         }
         else
         {
            System.out.println(n+" is not prime number ");
         }
    }
}